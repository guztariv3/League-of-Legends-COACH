import { z } from "zod";

/**
 * Live Client Data API (`https://127.0.0.1:2999/liveclientdata/allgamedata`),
 * the subset the Live Coach reads. It is exposed by the game itself during a
 * match and is read-only. Objects are loose and most fields optional, so a
 * missing field degrades a feature instead of breaking the Coach (verification
 * level V2, docs/01-investigacion.md).
 */

const Scores = z.looseObject({
  kills: z.number().default(0),
  deaths: z.number().default(0),
  assists: z.number().default(0),
  creepScore: z.number().default(0),
  wardScore: z.number().optional(),
});

const Item = z.looseObject({
  itemID: z.number(),
  displayName: z.string().optional(),
  price: z.number().optional(),
  count: z.number().optional(),
});

const Rune = z.looseObject({ id: z.number().int(), displayName: z.string().optional() });
const Spell = z.looseObject({ displayName: z.string() });

const AbilityRank = z.looseObject({ abilityLevel: z.number().optional(), displayName: z.string().optional() });

export const LivePlayer = z.looseObject({
  championName: z.string(),
  /** e.g. "game_character_displayname_MissFortune": the suffix is the Data Dragon id. */
  rawChampionName: z.string().optional(),
  riotId: z.string().optional(),
  summonerName: z.string().optional(),
  team: z.string(), // "ORDER" | "CHAOS"
  level: z.number().default(1),
  position: z.string().optional(),
  isDead: z.boolean().optional(),
  /** Seconds until a dead player respawns (0 when alive); public, shown on the scoreboard. */
  respawnTimer: z.number().optional(),
  isBot: z.boolean().optional(),
  items: z.array(Item).default([]),
  scores: Scores.optional(),
  summonerSpells: z.looseObject({ summonerSpellOne: Spell.optional(), summonerSpellTwo: Spell.optional() }).optional().catch(undefined),
});
export type LivePlayer = z.infer<typeof LivePlayer>;

export const LiveEvent = z.looseObject({
  EventID: z.number(),
  EventName: z.string(),
  EventTime: z.number(),
});
export type LiveEvent = z.infer<typeof LiveEvent>;

export const AllGameData = z.looseObject({
  activePlayer: z.looseObject({
    riotId: z.string().optional(),
    summonerName: z.string().optional(),
    level: z.number().optional(),
    currentGold: z.number().optional(),
    fullRunes: z.looseObject({ keystone: Rune.optional(), generalRunes: z.array(Rune).optional(), statRunes: z.array(Rune).optional() }).optional().catch(undefined),
    /** Health and resource right now (the Live Client Data API reports them for the active player only). */
    championStats: z.looseObject({
      currentHealth: z.number().optional(),
      maxHealth: z.number().optional(),
      resourceType: z.string().optional(),
      resourceValue: z.number().optional(),
      resourceMax: z.number().optional(),
    }).optional(),
    /** The player's own ability ranks (Q, W, E, R); only ever reported for the active player. */
    abilities: z.looseObject({
      Q: AbilityRank.optional(),
      W: AbilityRank.optional(),
      E: AbilityRank.optional(),
      R: AbilityRank.optional(),
    }).optional(),
  }),
  allPlayers: z.array(LivePlayer),
  events: z.looseObject({ Events: z.array(LiveEvent).default([]) }).default({ Events: [] }),
  gameData: z.looseObject({
    gameMode: z.string().optional(),
    gameTime: z.number(),
    mapNumber: z.number().optional(),
  }),
});
export type AllGameData = z.infer<typeof AllGameData>;
