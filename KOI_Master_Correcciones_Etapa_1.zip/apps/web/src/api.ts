/** Typed client for the Coach API. Types mirror apps/api responses. */

export type Mode = "summoners_rift" | "aram" | "unsupported";

export interface AppConfig {
  dataSource: "riot" | "synthetic";
  auth: { rso: boolean; devLogin: boolean; accounts?: boolean };
  aiEnabled: boolean;
  knowledgeVersion: string | null;
  platforms: { id: string; label: string }[];
}

/** Static game data for icons (see apps/api `/assets`). `cdn` is null for the synthetic catalog. */
export interface GameAssets {
  version: string | null;
  cdn: string | null;
  champions: { key: number; id: string; name: string }[];
  spells: { key: number; id: string; name: string }[];
  runes: { id: number; name: string; icon: string; style: boolean }[];
  items: { id: number; name: string }[];
}

export interface Account {
  id: string;
  riotId: string;
  platform: string;
  verified: boolean;
  includeInProfile: boolean;
  source: "riot" | "synthetic";
  sync: { status: "never" | "syncing" | "ok" | "error"; error: string | null; lastSyncedAt: string | null; progress: { done: number; total: number } | null };
}

export type MemoryCategory = "focus" | "correction" | "note";

export interface Preferences {
  level: "beginner" | "intermediate" | "advanced" | "expert";
  language: "es" | "en";
  memory: Record<MemoryCategory, boolean> & { patterns: boolean };
}

export interface Me {
  user: { id: string; displayName: string; username?: string | null; hasPassword?: boolean };
  accounts: Account[];
  preferences: Preferences;
}

export interface Insight {
  id: string;
  kind: "fact" | "observation" | "hypothesis";
  priority: "critical" | "important" | "info" | "suppressed";
  confidence: number;
  title: string;
  detail: string;
  evidence: { label: string; value: string }[];
  sampleSize: number;
  matchIds: string[];
  metric?: string;
  review?: string;
}

export interface MatchRow {
  matchId: string;
  accountId: string;
  startedAt: number;
  durationSec: number;
  mode: Mode;
  queue: string;
  queueId: number;
  patch: string;
  analyzable: boolean;
  win: boolean;
  championName: string;
  role: string;
  kills: number;
  deaths: number;
  assists: number;
  kda: number;
  csPerMin: number | null;
  goldDiff15: number | null;
  killParticipation: number | null;
  visionPerMin: number | null;
  opponent: string | null;
  headline: string | null;
  championId: number;
  level: number;
  gold: number;
  cs: number;
  items: number[];
  spells: number[];
  runes: { keystone: number | null; primary: number | null; secondary: number | null };
}

export interface ModeSummary {
  mode: Mode;
  games: number;
  wins: number;
  winRate: number;
  winRateInterval: { low: number; high: number };
  avgKda: number;
  avgCsPerMin: number | null;
  avgGoldDiff10: number | null;
  mainRole: string | null;
  champions: { championName: string; games: number; wins: number }[];
}

export interface Dashboard {
  dataSource: "riot" | "synthetic";
  syncing: boolean;
  summary: { totalGames: number; analyzableGames: number; timelineCoverage: number; modes: ModeSummary[] };
  insights: Insight[];
  insufficientData: boolean;
  recent: MatchRow[];
  performance: Performance;
}

export type Stat = { value: number; games: number } | null;
export interface Performance {
  mode: Mode | null;
  games: number;
  goldDiff15: Stat;
  goldShare: Stat;
  damageShare: Stat;
  killParticipation: Stat;
  soloDeaths: Stat;
  visionPerMin: Stat;
  roles: { role: string; games: number; wins: number }[];
}

export interface OverviewRow {
  kind: "role" | "champion";
  name: string;
  championId: number | null;
  games: number;
  wins: number;
  kills: number;
  deaths: number;
  assists: number;
  kda: number;
  csPerMin: number | null;
  killParticipation: number | null;
  lp: { value: number; games: number } | null;
  radar: { id: string; label: string; score: number | null; games: number }[];
  performance: { goldDiff15: Stat; goldShare: Stat; damageShare: Stat; damagePerMinDiff: Stat; soloDeaths: Stat; visionScore: Stat };
}
export interface Overview {
  queues: { queueId: number; label: string; ranked: boolean; rank: { tier: string; division: string; lp: number; wins: number; losses: number } | null; games: number; wins: number }[];
  selected: number | null;
  role: string | null;
  games: number;
  lpColumn: boolean;
  rows: OverviewRow[];
  axes: { id: string; label: string }[];
  lpTrack: { queue: "RANKED_SOLO_5x5" | "RANKED_FLEX_SR" | null; history: RankPoint[] };
  lastSyncedAt: string | null;
}

export interface GameCard {
  matchId: string; queueId: number; queue: string; patch: string; startedAt: number; durationSec: number;
  analyzable: boolean; win: boolean; championName: string; championId: number; role: string; level: number;
  kills: number; deaths: number; assists: number; kda: number; cs: number; csPerMin: number | null; csDiff15: number | null;
  killParticipation: number | null; visionScore: number | null; items: number[]; spells: number[];
  runes: { keystone: number | null; primary: number | null; secondary: number | null };
  lpChange: number | null; tags: string[];
  players: { teamId: number; championName: string; championId: number; name: string | null; isMe: boolean }[];
}
export interface SummaryGroup { games: number; wins: number; kills: number; deaths: number; assists: number; kda: number }
export interface OverviewGames {
  activity: { days: number; games: number; hours: number; list: { t: number; win: boolean; analyzable: boolean; mode: Mode; durationSec: number }[] };
  roles: { role: string; games: number; wins: number }[];
  summary: SummaryGroup & {
    role: (SummaryGroup & { role: string }) | null;
    champions: (SummaryGroup & { name: string; championId: number })[];
    games: { matchId: string; championName: string; championId: number; win: boolean; kills: number; deaths: number; assists: number; startedAt: number }[];
  };
  cards: GameCard[];
  total: number;
  champions: string[];
}

export interface MatchList {
  total: number;
  matches: MatchRow[];
  facets: { champions: string[]; patches: string[]; modes: Mode[] };
}

export interface MatchDetail {
  dataSource: "riot" | "synthetic";
  analysis: MatchRow & {
    killParticipation: number | null;
    damageShare: number | null;
    visionPerMin: number | null;
    goldDiff10: number | null;
    earlyDeaths: number | null;
    laneOpponentChampion: string | null;
    hasTimeline: boolean;
  };
  headline: string | null;
  /** Facts from the scoreboard and timeline, each with the number behind it. */
  achievements: { id: string; title: string; detail: string; scope: "game" | "personal" | "moment" }[];
  /** How the 1–10 ranking is computed; null when the game isn't ranked (remakes, other modes). */
  ranking: { explanation: string } | null;
  teams: {
    teamId: number;
    win: boolean;
    players: { championName: string; riotId: string | null; role: string; kills: number; deaths: number; assists: number; cs: number; gold: number; damage: number; championId: number; items: { id: number; name: string }[]; spells: number[]; runes: { keystone: number | null; primary: number | null; secondary: number | null }; isMe: boolean; rank: number | null; score: number | null }[];
  }[];
  goldCurve: { minute: number; me: number; opponent: number | null }[] | null;
  myEvents: { minute: number; type: "kill" | "death" | "assist" }[] | null;
}

export interface ChampionList {
  version: string | null;
  source: "ddragon" | "synthetic" | null;
  /** Credit for the positions, when they're present (League of Legends Wiki via Meraki). */
  positionsSource: WikiAttribution | null;
  champions: { id: string; key: number; name: string; title: string; tags: string[]; positions: string[]; info?: { attack: number; defense: number; magic: number; difficulty: number }; personal: { games: number; wins: number } }[];
}

export interface Dimension {
  id: string;
  label: string;
  headline: string;
  metrics: { label: string; value: string }[];
  sampleSize: number;
  confidence: number;
  trend: "improving" | "declining" | "stable" | "unknown";
}

export interface StateBucket {
  state: "ahead" | "even" | "behind";
  games: number;
  wins: number;
  winRate: number;
  interval: { low: number; high: number };
  lateDeathsPerMin: number | null;
}

export interface MemoryPattern {
  id: string;
  kind: "mistake" | "strength";
  scope: "champion" | "role" | "all";
  text: string;
  why: string;
  games: number;
  hits: number;
}
export interface PlayerMemory {
  patterns: MemoryPattern[];
  style: { style: "aggressive" | "balanced" | "safe"; why: string; games: number } | null;
}

export interface Profile {
  profiles: { mode: Mode; mainRole: string | null; games: number; dimensions: Dimension[] }[];
  gameState: StateBucket[];
  /** Recurring patterns and playstyle (phase 5); null when turned off. */
  memory: PlayerMemory | null;
}

export interface Goal {
  id: string;
  metric: string;
  target: number;
  title: string;
  note: string | null;
  source: "coach" | "user";
  createdAt: string;
  progress: { games: number; met: number; rate: number; baselineRate: number; status: "collecting" | "in_progress" | "consolidated"; summary: string };
}

export interface GoalSuggestion {
  metric: string;
  target: number;
  title: string;
  reason: string;
}

export interface GoalsResponse {
  goals: Goal[];
  suggestions: GoalSuggestion[];
  max: number;
  metrics: { id: string; label: string }[];
}

export interface MemoryItem {
  id: string;
  category: MemoryCategory;
  content: string;
  ref: string | null;
  createdAt: string;
}

export interface SearchResult {
  type: "champion" | "matchup" | "matches" | "profile" | "insight";
  title: string;
  subtitle?: string;
  href: string;
}

export interface Ability { key: "P" | "Q" | "W" | "E" | "R"; name: string; description: string; cooldown: string | null; cost: string | null; range: string | null; image: string }

export interface WikiAttribution { text: string; license: string; wiki: string; meraki: string }
export interface WikiChampion {
  key: string;
  name: string;
  positions: string[];
  roles: string[];
  attackType: string | null;
  adaptiveType: string | null;
  ratings: { damage: number; toughness: number; control: number; mobility: number; utility: number; abilityReliance: number; difficulty: number } | null;
  abilities: { key: "P" | "Q" | "W" | "E" | "R"; name: string; blurb: string | null; damageType: string | null; targeting: string | null; cooldown: string | null; cost: string | null; effects: { description: string; values: { label: string; value: string }[] }[] }[];
  patchLastChanged: string | null;
}
export interface ChampionDetail {
  champion: { id: string; key: number; name: string; title: string; tags: string[]; info?: { attack: number; defense: number; magic: number; difficulty: number } } | null;
  knowledgeVersion: string | null;
  abilities: { abilities: Ability[]; allyTips: string[]; enemyTips: string[] } | null;
  /** League of Legends Wiki data via Meraki (CC BY-SA 3.0); null when unavailable. */
  wiki: (WikiChampion & { attribution: WikiAttribution }) | null;
  personal: {
    games: number;
    wins: number;
    interval: { low: number; high: number };
    comparisons: { label: string; value: string; others: string | null; verdict: "better" | "worse" | "similar"; sample: number }[];
    opponents: { opponent: string; games: number; wins: number; kda: number | null; csDiff15: number | null; goldDiff15: number | null }[];
    loadout: GamePlan["loadout"];
    /** Most common levelling order with the champion (1 = Q … 4 = R). */
    skillOrder: number[] | null;
    build: { games: number; items: { id: number; name: string; games: number; wins: number }[]; note: string | null };
    recent: { matchId: string; win: boolean; kills: number; deaths: number; assists: number; startedAt: number; mode: Mode }[];
  };
}

export type MomentCategory = "error" | "opportunity" | "good" | "event";

export interface KeyMoment {
  id: string;
  t: number;
  category: MomentCategory;
  kind: "fact" | "observation" | "hypothesis";
  confidence: number;
  title: string;
  detail: string;
  evidence: { label: string; value: string }[];
  goldSwing: number;
  position: { x: number; y: number } | null;
}

export interface MatchReview {
  matchId: string;
  me: number;
  durationSec: number;
  participants: { id: number; championName: string; teamId: number; role: string; isMe: boolean; isAlly: boolean }[];
  frames: { minute: number; positions: { id: number; x: number; y: number }[]; teamGoldDiff: number }[];
  events: { t: number; type: "kill" | "objective" | "structure"; label: string; position: { x: number; y: number } | null; side: "ally" | "enemy"; myInvolvement: "killer" | "victim" | "assist" | null }[];
  moments: KeyMoment[];
  highlights: string[];
  limits: string[];
}

/** A Coach recommendation or finding (the engine's CoachDecision shape). */
export interface CoachDecision {
  id: string;
  kind: string;
  basis: "fact" | "observation" | "hypothesis";
  priority: "critical" | "important" | "info";
  confidence: number;
  headline: string;
  ref?: string;
  reasons: string[];
  evidence: { label: string; value: string; source: "this_game" | "your_games" | "game_data" | "global_stats"; sampleSize?: number }[];
  alternatives: { label: string; ref?: string; reason?: string }[];
}

export type ReviewSectionId = "went_well" | "hurt" | "biggest_mistake" | "missed_opportunity" | "build" | "skills" | "macro" | "focus";
export interface CoachReview {
  sections: { id: ReviewSectionId; title: string; decisions: CoachDecision[]; empty: string | null }[];
  baseline: { games: number; scope: string };
}

export type ReviewResponse = { available: true; dataSource: "riot" | "synthetic"; review: MatchReview; coach: CoachReview } | { available: false; message: string };

export interface DraftPoint {
  id: string;
  kind: "fact" | "observation" | "hypothesis";
  title: string;
  detail: string;
  weight: number;
}

export interface Composition {
  champions: { id: string; name: string; tags: string[] }[];
  frontline: number;
  classes: Record<string, number>;
  magicShare: number | null;
  unrated: number;
}

export interface PlanLine { text: string; basis: "fact" | "observation" | "hypothesis"; why: string }
export interface GamePlan {
  primaryObjective: PlanLine | null;
  secondaryObjective: PlanLine | null;
  biggestThreat: PlanLine | null;
  yourPowerSpike: PlanLine | null;
  enemyPowerSpike: PlanLine | null;
  avoid: PlanLine | null;
  lookFor: PlanLine | null;
  loadout: {
    games: number;
    keystone: { id: number; name: string; games: number } | null;
    spells: { ids: number[]; names: string[]; games: number } | null;
    maxOrder: string[] | null;
    firstItem: { id: number; name: string; games: number; medianMinute: number | null } | null;
  };
}

export interface DraftAnalysis {
  /** The Coach's game plan for these champions. */
  plan?: GamePlan;
  ally: Composition;
  enemy: Composition;
  keyPoints: DraftPoint[];
  morePoints: DraftPoint[];
  personal: { withChampion: { games: number; wins: number }; vsOpponent: { games: number; wins: number } | null };
  unknownChampions: string[];
  limits: string[];
}

export interface ScoutedPlayer {
  riotId: string | null;
  championId: string;
  championName: string;
  available: boolean;
  games: number;
  wins: number;
  gamesOnChampion: number;
  winsOnChampion: number;
  mainRole: string | null;
  avgKda: number | null;
  smallSample: boolean;
  headline: string;
  rankStatus: "ranked" | "unranked" | "unavailable";
  rank: { queue: "solo" | "flex"; tier: string | null; division: string | null; lp: number | null; wins: number; losses: number } | null;
  topChampions: { id: string; name: string; points: number | null; games: number | null }[];
  topSource: "mastery" | "recent" | null;
}

export interface ScoutResult {
  inGame: boolean;
  /** Riot ID of the linked account that is in the game. */
  account?: string;
  simulated?: boolean;
  message?: string;
  myChampion?: { id: string; name: string };
  allies?: { id: string; name: string }[];
  enemies?: ScoutedPlayer[];
  draft?: DraftAnalysis;
}

export interface Inflection {
  metric: string;
  label: string;
  at: number;
  before: { mean: number; n: number };
  after: { mean: number; n: number };
  direction: "improved" | "declined";
  attribution: "player" | "environment_possible" | "unclear";
  kind: "observation" | "hypothesis";
  context: string[];
}

export interface Evolution {
  inflections: Inflection[];
  anomalies: { metric: string; label: string; direction: "better" | "worse"; count: number; verdict: "variance" | "possible_change"; explanation: string }[];
  timeline: { at: number; type: "inflection" | "champion_shift" | "patch"; title: string; detail: string }[];
  adaptation: {
    byOpponentClass: AdaptationContext[];
    lead: AdaptationContext | null;
  };
  games: number;
}

export interface AdaptationContext {
  id: string;
  label: string;
  games: number;
  verdict: "insufficient" | "over" | "no_clear_difference";
  detail: string;
  metrics: { label: string; here: string; elsewhere: string }[];
}

export interface DecisionHistory {
  note: string;
  items: { id: string; kind: "goal_suggestion" | "insight" | "draft"; title: string; decision: "accepted" | "rejected" | "dismissed" | "none" | null; createdAt: string; outcome: string | null }[];
}

export class ApiError extends Error {
  constructor(readonly status: number, readonly code: string, message: string) {
    super(message);
  }
}

export interface DesktopDevice {
  id: string;
  label: string;
  claimedAt: string;
  lastUsedAt: string | null;
}

async function request<T>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers);
  if (init.body) headers.set("Content-Type", "application/json");
  const res = await fetch(`/api${path}`, { ...init, headers, credentials: "same-origin" });
  const body = await res.json().catch(() => ({}));
  if (!res.ok) throw new ApiError(res.status, body.error ?? "error", body.message ?? "Could not complete the action.");
  return body as T;
}

export type PoolVerdict = "strong" | "weak" | "even" | "few";
export interface PoolEntry {
  name: string;
  games: number;
  wins: number;
  interval: { low: number; high: number };
  verdict: PoolVerdict;
  kda: number;
  csPerMin: number | null;
  goldDiff15: number | null;
  csDiff15: number | null;
  lastPlayed: number;
}
export interface Improve {
  champions: PoolEntry[];
  matchups: PoolEntry[];
  matchupChampion: string | null;
  activity: { t: number; win: boolean; mode: "summoners_rift" | "aram" | "unsupported"; analyzable: boolean }[];
  activityDays: number;
}
export interface Challenge {
  id: string;
  metric: string;
  kind: "next5" | "week";
  target: number;
  title: string;
  createdAt: string;
  closedAt: string | null;
  status: "active" | "completed" | "failed" | "abandoned";
  progress: { status: "in_progress" | "completed" | "failed"; met: number; played: number; results: boolean[]; endsAt: number | null; summary: string };
}
export interface ChallengesResponse {
  active: Challenge[];
  recent: Challenge[];
  completedCount: number;
  suggestions: { metric: string; target: number; title: string; recent: { met: number; n: number } }[];
  max: number;
}
export interface RankPoint { at: string; tier: string; rank: string; lp: number; wins: number; losses: number; lpChange: number | null; points: number | null }
export interface RankResponse {
  accounts: { accountId: string; riotId: string; queues: { queueType: "RANKED_SOLO_5x5" | "RANKED_FLEX_SR"; current: RankPoint; history: RankPoint[] }[] }[];
}

export const api = {
  live: () => request<{frame: import("@coach/ui").LiveFrame | null; stale:boolean}>("/live", {signal:AbortSignal.timeout(5000)}),
  config: () => request<AppConfig>("/config"),
  assets: () => request<GameAssets>("/assets"),
  me: () => request<Me>("/me"),
  devLogin: (displayName: string) => request<{ user: Me["user"] }>("/auth/dev-login", { method: "POST", body: JSON.stringify({ displayName }) }),
  register: (username: string, password: string) => request<{ user: Me["user"] }>("/auth/register", { method: "POST", body: JSON.stringify({ username, password }) }),
  signIn: (username: string, password: string) => request<{ user: Me["user"] }>("/auth/login", { method: "POST", body: JSON.stringify({ username, password }) }),
  setCredentials: (username: string, password: string, currentPassword?: string) =>
    request<{ ok: true; username: string }>("/me/credentials", { method: "PUT", body: JSON.stringify({ username, password, ...(currentPassword ? { currentPassword } : {}) }) }),
  logout: () => request<{ ok: true }>("/auth/logout", { method: "POST", body: "{}" }),
  deleteMe: () => request<{ ok: true }>("/me", { method: "DELETE" }),
  linkAccount: (gameName: string, tagLine: string, platform: string) =>
    request<{ account: Account }>("/accounts", { method: "POST", body: JSON.stringify({ gameName, tagLine, platform }) }),
  updateAccount: (id: string, includeInProfile: boolean) =>
    request<{ account: Account }>(`/accounts/${id}`, { method: "PATCH", body: JSON.stringify({ includeInProfile }) }),
  deleteAccount: (id: string) => request<{ ok: true }>(`/accounts/${id}`, { method: "DELETE" }),
  desktopPair: () => request<{ code: string; expiresInSec: number }>("/desktop/pair", { method: "POST", body: "{}" }),
  desktopDevices: () => request<{ devices: DesktopDevice[] }>("/desktop/devices"),
  desktopRevoke: (id: string) => request<{ ok: true }>(`/desktop/devices/${id}`, { method: "DELETE" }),
  syncAll: () => request<{ started: string[] }>("/sync", { method: "POST", body: "{}" }),
  dashboard: () => request<Dashboard>("/dashboard"),
  matches: (params: Record<string, string>) => request<MatchList>(`/matches?${new URLSearchParams(params)}`),
  match: (id: string) => request<MatchDetail>(`/matches/${encodeURIComponent(id)}`),
  champions: () => request<ChampionList>("/champions"),
  explain: (insightId: string) =>
    request<{ text: string; source: "ai" | "deterministic" }>("/coach/explain", { method: "POST", body: JSON.stringify({ insightId }) }),
  savePreferences: (p: Partial<Preferences>) => request<Preferences>("/preferences", { method: "PUT", body: JSON.stringify(p) }),
  profile: () => request<Profile>("/profile"),
  goals: () => request<GoalsResponse>("/goals"),
  createGoal: (metric: string, source: "coach" | "user", target?: number) =>
    request<{ goal: { id: string; title: string } }>("/goals", { method: "POST", body: JSON.stringify({ metric, source, target }) }),
  rejectGoal: (metric: string) => request<{ ok: true }>("/goals/reject", { method: "POST", body: JSON.stringify({ metric }) }),
  closeGoal: (id: string, status: "achieved" | "archived") => request<{ ok: true }>(`/goals/${id}`, { method: "PATCH", body: JSON.stringify({ status }) }),
  memory: () => request<{ categories: Preferences["memory"]; items: MemoryItem[] }>("/memory"),
  addNote: (content: string) => request<{ item: MemoryItem }>("/memory", { method: "POST", body: JSON.stringify({ category: "note", content }) }),
  setFocus: (metric: string) => request<{ item: MemoryItem }>("/memory", { method: "POST", body: JSON.stringify({ category: "focus", metric }) }),
  deleteMemory: (id: string) => request<{ ok: true }>(`/memory/${id}`, { method: "DELETE" }),
  clearMemory: (category?: MemoryCategory) => request<{ ok: true }>(`/memory${category ? `?category=${category}` : ""}`, { method: "DELETE" }),
  feedback: (insightId: string, title: string) =>
    request<{ ok: true; stored: boolean }>("/coach/feedback", { method: "POST", body: JSON.stringify({ insightId, title }) }),
  search: (q: string) => request<{ results: SearchResult[] }>(`/search?q=${encodeURIComponent(q)}`),
  champion: (name: string) => request<ChampionDetail>(`/champions/${encodeURIComponent(name)}`),
  review: (matchId: string) => request<ReviewResponse>(`/matches/${encodeURIComponent(matchId)}/review`),
  draft: (input: { myChampion: string; allies: string[]; enemies: string[]; laneOpponent?: string }) =>
    request<DraftAnalysis>("/draft", { method: "POST", body: JSON.stringify(input) }),
  scout: () => request<ScoutResult>("/game/scout"),
  evolution: () => request<Evolution>("/evolution"),
  history: () => request<DecisionHistory>("/history"),
  clearHistory: () => request<{ ok: true }>("/history", { method: "DELETE" }),
  improve: (champion?: string) => request<Improve>(`/improve${champion ? `?champion=${encodeURIComponent(champion)}` : ""}`),
  rank: () => request<RankResponse>("/rank"),
  overviewGames: (params: Record<string, string>) => request<OverviewGames>(`/overview/games?${new URLSearchParams(params)}`),
  overview: (queue?: number) => request<Overview>(`/overview${queue ? `?queue=${queue}` : ""}`),
  challenges: () => request<ChallengesResponse>("/challenges"),
  acceptChallenge: (metric: string, kind: "next5" | "week") =>
    request<{ challenge: Challenge }>("/challenges", { method: "POST", body: JSON.stringify({ metric, kind }) }),
  dropChallenge: (id: string) => request<{ ok: true }>(`/challenges/${id}`, { method: "DELETE" }),
};
